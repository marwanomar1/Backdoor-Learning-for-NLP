# activation_clustering_defence

To run experiment:

```
python poison_defense_activation_clustering.py --model_name_or_path "./saved_models/bert_base_uncased" --data_path "./datasets/sst2" --save_model_path "./results" --poison_rate .5
```
